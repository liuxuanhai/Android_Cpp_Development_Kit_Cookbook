#include "com_packtpub_store_Store.h"

JNIEXPORT jint JNICALL Java_com_packtpub_store_Store_getCount
  (JNIEnv* pEnv, jobject pObject) {
    return 10;
//	pEnv = 0;
//	return pEnv->CallIntMethod(0, 0);
}
