Chatper 1 contains the following code:
HelloNDK: a simple Android app display a "Hello NDK" message on phone screen. It demontrates the basic usage of Android NDK.
Usage: use Eclipse to import the project.  
